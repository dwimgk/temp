#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <conio.h>

#include "functions.h"
#include "globals.h"

// gcc -o tetris.exe main.c functions.c globals.c

void game_init();
void play();
void scoreboard();

int main()
{
    player = (char *)malloc(100 * sizeof(char));
    if (player == NULL)
    {
        printf("could not allocate memory\n");
        return 4;
    }

    int input;
    system("cls");
    printf("TTTTTTT EEEEE TTTTTTT   RRRRR    IIIII  SSSSSS\n");
    printf("   T    E        T      R    R     I	S \n");
    printf("   T    EEEEE    T      RRRRR      I    SSSSSS\n");
    printf("   T    E        T      R   R      I         S\n");
    printf("   T    EEEEE    T      R    RR  IIIII  SSSSSS\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("1. PLAY\n");
    printf("2. Scoreboard\n");
    printf("3. Exit program\n");
    printf("What do you wish to do?");
    input = scanf("%d", &input);
    if (input == 1)
    {
        play();
        //return 1;
    }
    else if (input == 2)
    {
        scoreboard();
        //return 2;
    }

    return 0;
}

void scoreboard()
{
    FILE *file = fopen("score.txt", "r");
    if (file == NULL)
    {
        perror("error opening file");
        return;
    }

    char ch;
    while ((ch = fgetc(file)) != EOF)
    {
        putchar(ch);
    }

    fclose(file);
    return;
}
void play()
{
    printf("Enter player name: ");

    fgets(player, 100, stdin);
    size_t length = strlen(player);
    if (length > 0 && player[length - 1] == '\n')
    {
        player[length - 1] = '\0';
    }

    game_init();

    FILE *file = fopen("score.txt", "a");
    if (file == NULL)
    {
        perror("failed to open file");
        return;
    }
    fprintf(file, "Player: %s\n", player);
    fprintf(file, "Score: %d\n\n", score);

    // Close the file
    fclose(file);

    free(player);
    return;
}
void game_init()
{
    memcpy(non_dynamic_playfield, playfield, sizeof(non_dynamic_playfield));
    // seeding with time(null) so that every random num will be different each iteration of the code
    srand(time(NULL));

    system("cls");

    bool game_running = true;
    current_shape_isplaced = false;

    pos_row = start_pos_row;
    pos_col = start_pos_col;

    shape_initialiser();

    while (game_running)
    {
        if (game_stop)
        {
            end_screen();
            return;
        }

        cannot_move_to_left = false;
        cannot_move_to_right = false;

        position_shapes();
        print_playfield();
        if (current_shape_isplaced)
        {
            memcpy(non_dynamic_playfield, playfield, sizeof(non_dynamic_playfield));
            shape_initialiser();
            pos_row = start_pos_row;
            pos_col = start_pos_col;
            current_shape_isplaced = false;
        }
        else if (!current_shape_isplaced)
        {
            memcpy(playfield, non_dynamic_playfield, sizeof(playfield));
            pos_row++;
        }
        long sleep_time = 150000 - score * 20000;
        if (sleep_time < 0)
        {
            sleep_time = 0;
        }
        usleep(sleep_time);
        // 50 000 microseconds = 0.5s

        proccess_input();
        clear_input();

        line_checker();
    }
    return;
}